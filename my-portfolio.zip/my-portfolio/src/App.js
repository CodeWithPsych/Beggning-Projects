import React from 'react';
import './App.css';
import Navbar from './components/Navbar/Navbar';
import Hero from './components/Hero/hero';
import About from './components/About/about';
import Skill from './components/Skill/skill'
// import AnimatedBeam from './@/components/magicui/animated-beam'

const App = () => {
  return (
    <div>
      <Navbar />
      <Hero />
      <About />
      <Skill />
      {/* <AnimatedBeam /> */}
    </div>
  );
}

export default App;
