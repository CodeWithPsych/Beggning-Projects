import React from 'react';
import './Navbar.css'

const Navbar = () => {
  return (
    <div className='navbar'>
      <div className="left">Code With Psych</div>
      <div className="right">
        <ul>
            <li><a className='navList' href="#">About</a></li>
            <li><a className='navList' href="#">Skills</a></li>
            <li><a className='navList' href="#">Portfolio</a></li>
            <li><a className='navList' href="#">Education</a></li>
        </ul>
      </div>
    </div>
  );
}

export default Navbar;
