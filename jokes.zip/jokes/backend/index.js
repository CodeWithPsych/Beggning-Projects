import express from 'express';
import { readFileSync } from 'fs';
const jokesJson = JSON.parse(readFileSync('jokes.json', 'utf-8'));
const data = jokesJson.jokes;
const app = express();
const port = process.env.PORT || 3001;

app.get("/api/jokes", (req, res) => {
    res.status(200).json(data);
    console.log("Server started");
})
app.listen(port, () => {
    console.log(`server is running on http://localhost:${port}`)
})