import React, { useEffect, useState } from "react";
import axios from "axios";
import "./App.css";

function App() {
  const [jokes, setJokes] = useState([]);

  useEffect(() => {
    axios
      .get("/api/jokes")
      .then((response) => {
        setJokes(response.data);
      })
      .catch((error) => {
        console.log("its error " + error);
      });
  }, []);

  return (
    <div>
      <h1>Jokes</h1>
      <h3 style={{ color: "red" }}>
        <i>Number of Jokes: {jokes.length}</i>
      </h3>
      {jokes.map((joke) => (
        <div key={joke.id}>
          <h3 style={{ color: "greenyellow" }}>
            {joke.id}: {joke.title}
          </h3>
          <p style={{ color: "lightgreen" }}>{joke.content}</p>
        </div>
      ))}
    </div>
  );
}

export default App;
